/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.made_lavant;

/**
 *
 * @autores Daniel Jorge Reis Caldeira - 202065555C
 * Ewerson dos Santos Rodrigues - 201965029AB 
 * Marcio Felipe Daniel Gonçalves - 202065519B 
 * Matheus Reis Ribeiro - 201965090AB
 */
public class MADE_LAVANT {

    public static void main(String[] args) {
        
        System.out.print("Ola mundo!");
<<<<<<< HEAD
<<<<<<< HEAD
       
=======
>>>>>>> 1248abb3a636d4032140d4782d340f890cc93d84
=======
>>>>>>> 1248abb3a636d4032140d4782d340f890cc93d84
    }
}
